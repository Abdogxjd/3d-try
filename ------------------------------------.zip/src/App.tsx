import { useState, useCallback } from "react";
import CodeEditor from "./components/CodeEditor";
import DiffViewer from "./components/DiffViewer";
import InstructionsPanel from "./components/InstructionsPanel";
import { applyPatch, parseAIResponse, computeDiff, type DiffLine, type ChangeDetail } from "./lib/patcher";

type Tab = "code" | "patch" | "result" | "diff";

export default function App() {
  const [originalCode, setOriginalCode] = useState("");
  const [patchInput, setPatchInput] = useState("");
  const [resultCode, setResultCode] = useState("");
  const [diff, setDiff] = useState<DiffLine[]>([]);
  const [changes, setChanges] = useState<ChangeDetail[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<Tab>("code");
  const [isApplying, setIsApplying] = useState(false);
  const [applied, setApplied] = useState(false);
  const [copiedResult, setCopiedResult] = useState(false);
  const [showPatchModal, setShowPatchModal] = useState(false);

  const handleApplyPatch = useCallback(() => {
    if (!originalCode.trim()) {
      setErrors(["❌ يرجى إدخال الكود الأصلي أولاً"]);
      return;
    }
    if (!patchInput.trim()) {
      setErrors(["❌ يرجى إدخال التعديلات أولاً"]);
      return;
    }

    setIsApplying(true);
    setErrors([]);
    setChanges([]);

    // Small delay for UX
    setTimeout(() => {
      const instruction = parseAIResponse(patchInput);
      if (!instruction) {
        setErrors([
          "❌ تعذر قراءة التعديلات. تأكد من أن التنسيق صحيح (JSON).",
          "💡 تأكد من أن رد الذكاء الاصطناعي يحتوي على JSON بالتنسيق المطلوب.",
        ]);
        setIsApplying(false);
        return;
      }

      const result = applyPatch(originalCode, instruction);
      setResultCode(result.code);
      setChanges(result.changes);
      setErrors(result.errors);
      setDiff(computeDiff(originalCode, result.code));
      setApplied(true);
      setActiveTab("result");
      setIsApplying(false);
      setShowPatchModal(false);
    }, 300);
  }, [originalCode, patchInput]);

  const handleCopyResult = async () => {
    try {
      await navigator.clipboard.writeText(resultCode);
      setCopiedResult(true);
      setTimeout(() => setCopiedResult(false), 2500);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = resultCode;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopiedResult(true);
      setTimeout(() => setCopiedResult(false), 2500);
    }
  };

  const handleReset = () => {
    setOriginalCode("");
    setPatchInput("");
    setResultCode("");
    setDiff([]);
    setChanges([]);
    setErrors([]);
    setApplied(false);
    setActiveTab("code");
  };

  const handleUseResultAsBase = () => {
    setOriginalCode(resultCode);
    setResultCode("");
    setPatchInput("");
    setDiff([]);
    setChanges([]);
    setErrors([]);
    setApplied(false);
    setActiveTab("code");
  };

  const tabs: { id: Tab; label: string; icon: string; badge?: number }[] = [
    { id: "code", label: "الكود الأصلي", icon: "📄" },
    { id: "patch", label: "التعديلات", icon: "✏️" },
    { id: "result", label: "النتيجة", icon: "✅" },
    { id: "diff", label: "المقارنة", icon: "📊", badge: changes.length },
  ];

  return (
    <div className="min-h-screen bg-gray-950 text-white" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-gray-900/95 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-[1800px] mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 flex items-center justify-center shadow-lg shadow-purple-500/20">
                <span className="text-xl">⚡</span>
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tight bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
                  CodePatcher
                </h1>
                <p className="text-[10px] text-gray-500 -mt-0.5">أداة تعديل الكود الذكية</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {applied && (
                <button
                  onClick={handleUseResultAsBase}
                  className="px-3 py-2 text-xs rounded-lg bg-purple-500/20 text-purple-400 border border-purple-500/30 hover:bg-purple-500/30 transition-all font-medium"
                >
                  🔄 استخدام النتيجة ككود أساسي
                </button>
              )}
              <button
                onClick={handleReset}
                className="px-3 py-2 text-xs rounded-lg bg-gray-800 text-gray-400 hover:bg-gray-700 hover:text-white transition-all font-medium"
              >
                🗑️ مسح الكل
              </button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-[1800px] mx-auto px-4 py-4 space-y-4">
        {/* Instructions Panel */}
        <InstructionsPanel />

        {/* Action Buttons Bar */}
        <div className="flex flex-wrap items-center gap-3 p-4 bg-gray-800/60 rounded-xl border border-gray-700/50">
          <button
            onClick={() => setShowPatchModal(true)}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-white font-bold text-sm transition-all shadow-lg shadow-orange-500/20 flex items-center gap-2"
          >
            ✏️ لصق التعديلات
          </button>

          <button
            onClick={handleApplyPatch}
            disabled={isApplying || !originalCode.trim() || !patchInput.trim()}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-400 hover:to-emerald-400 text-white font-bold text-sm transition-all shadow-lg shadow-green-500/20 flex items-center gap-2 disabled:opacity-40 disabled:cursor-not-allowed disabled:hover:from-green-500 disabled:hover:to-emerald-500"
          >
            {isApplying ? (
              <>
                <span className="animate-spin">⏳</span> جاري التطبيق...
              </>
            ) : (
              <>⚡ تطبيق التعديلات</>
            )}
          </button>

          {applied && (
            <button
              onClick={handleCopyResult}
              className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 shadow-lg ${
                copiedResult
                  ? "bg-green-500/30 text-green-300 border border-green-500/40 shadow-green-500/10"
                  : "bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-400 hover:to-cyan-400 text-white shadow-blue-500/20"
              }`}
            >
              {copiedResult ? "✓ تم نسخ الكود!" : "📋 نسخ الكود النهائي"}
            </button>
          )}

          {patchInput.trim() && (
            <span className="text-xs text-gray-500 mr-auto">
              ✓ التعديلات جاهزة للتطبيق
            </span>
          )}
        </div>

        {/* Errors */}
        {errors.length > 0 && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 space-y-2">
            <h4 className="text-red-400 font-bold text-sm flex items-center gap-2">
              <span>⚠️</span> أخطاء أثناء التطبيق
            </h4>
            {errors.map((err, i) => (
              <div key={i} className="text-red-300 text-xs bg-red-500/5 rounded-lg p-3 border border-red-500/10" dir="ltr">
                <pre className="whitespace-pre-wrap font-mono">{err}</pre>
              </div>
            ))}
          </div>
        )}

        {/* Changes Summary */}
        {applied && changes.length > 0 && (
          <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4">
            <h4 className="text-green-400 font-bold text-sm flex items-center gap-2 mb-3">
              <span>✅</span> تم تطبيق {changes.length} تعديل بنجاح
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
              {changes.map((change, i) => (
                <div
                  key={i}
                  className={`text-xs rounded-lg p-2.5 border flex items-start gap-2 ${
                    change.type === "added"
                      ? "bg-green-500/5 border-green-500/20 text-green-300"
                      : change.type === "removed"
                      ? "bg-red-500/5 border-red-500/20 text-red-300"
                      : "bg-blue-500/5 border-blue-500/20 text-blue-300"
                  }`}
                >
                  <span className="shrink-0">
                    {change.type === "added" ? "➕" : change.type === "removed" ? "➖" : "🔄"}
                  </span>
                  <div>
                    <div className="font-medium">{change.description}</div>
                    <div className="text-gray-500 mt-0.5">
                      أسطر {change.lineStart}-{change.lineEnd}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex border-b border-gray-800">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-5 py-3 text-sm font-medium transition-all relative ${
                activeTab === tab.id
                  ? "text-white"
                  : "text-gray-500 hover:text-gray-300"
              }`}
            >
              <span className="flex items-center gap-2">
                <span>{tab.icon}</span>
                {tab.label}
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className="bg-indigo-500/30 text-indigo-300 text-[10px] px-1.5 py-0.5 rounded-full">
                    {tab.badge}
                  </span>
                )}
              </span>
              {activeTab === tab.id && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full" />
              )}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="min-h-[500px]">
          {activeTab === "code" && (
            <div className="h-[600px]">
              <CodeEditor
                value={originalCode}
                onChange={setOriginalCode}
                placeholder="الصق الكود الأصلي هنا..."
                label="📄 الكود الأصلي"
              />
            </div>
          )}

          {activeTab === "patch" && (
            <div className="h-[600px]">
              <CodeEditor
                value={patchInput}
                onChange={setPatchInput}
                placeholder='الصق تعديلات JSON هنا...\n\n{\n  "modifications": [\n    {\n      "action": "replace",\n      "find": "الكود القديم",\n      "content": "الكود الجديد",\n      "description": "وصف التعديل"\n    }\n  ]\n}'
                label="✏️ التعديلات (JSON)"
              />
            </div>
          )}

          {activeTab === "result" && (
            <div className="h-[600px]">
              {resultCode ? (
                <CodeEditor
                  value={resultCode}
                  onChange={setResultCode}
                  readOnly
                  label="✅ الكود بعد التعديل"
                />
              ) : (
                <div className="h-full flex items-center justify-center bg-gray-900 rounded-xl border border-gray-700">
                  <div className="text-center space-y-3">
                    <div className="text-5xl">📝</div>
                    <p className="text-gray-500 text-sm">
                      لم يتم تطبيق أي تعديلات بعد
                    </p>
                    <p className="text-gray-600 text-xs">
                      الصق الكود الأصلي ← الصق التعديلات ← اضغط تطبيق
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === "diff" && (
            <div className="h-[600px]">
              {diff.length > 0 ? (
                <DiffViewer diff={diff} onClose={() => setActiveTab("result")} />
              ) : (
                <div className="h-full flex items-center justify-center bg-gray-900 rounded-xl border border-gray-700">
                  <div className="text-center space-y-3">
                    <div className="text-5xl">📊</div>
                    <p className="text-gray-500 text-sm">
                      لا توجد مقارنة حتى الآن
                    </p>
                    <p className="text-gray-600 text-xs">
                      طبّق التعديلات أولاً لرؤية المقارنة
                    </p>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>

      {/* Patch Modal */}
      {showPatchModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-gray-900 rounded-2xl border border-gray-700 shadow-2xl w-full max-w-3xl max-h-[80vh] flex flex-col">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-700">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <span>✏️</span> لصق التعديلات
              </h3>
              <button
                onClick={() => setShowPatchModal(false)}
                className="text-gray-400 hover:text-white transition-colors p-1.5 rounded-lg hover:bg-gray-700"
              >
                ✕
              </button>
            </div>
            <div className="flex-1 p-5 overflow-hidden">
              <div className="h-[400px]">
                <CodeEditor
                  value={patchInput}
                  onChange={setPatchInput}
                  placeholder='الصق رد الذكاء الاصطناعي هنا...'
                  label="📝 رد الذكاء الاصطناعي (JSON)"
                />
              </div>
            </div>
            <div className="flex items-center justify-between px-5 py-4 border-t border-gray-700 bg-gray-800/50">
              <p className="text-xs text-gray-500">
                الصق رد الذكاء الاصطناعي كاملاً، النظام سيستخرج JSON تلقائياً
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowPatchModal(false)}
                  className="px-4 py-2 rounded-xl bg-gray-700 text-gray-300 hover:bg-gray-600 text-sm font-medium transition-all"
                >
                  إلغاء
                </button>
                <button
                  onClick={handleApplyPatch}
                  disabled={!patchInput.trim() || !originalCode.trim()}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-400 hover:to-emerald-400 text-white font-bold text-sm transition-all disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  ⚡ تطبيق التعديلات
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-gray-800 mt-8">
        <div className="max-w-[1800px] mx-auto px-4 py-4 text-center">
          <p className="text-gray-600 text-xs">
            CodePatcher ⚡ أداة تعديل الكود الذكية — وفّر التوكينات والوقت
          </p>
        </div>
      </footer>
    </div>
  );
}
