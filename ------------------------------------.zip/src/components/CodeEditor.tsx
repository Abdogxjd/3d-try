import { useRef, useEffect, useState, useCallback } from "react";

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  readOnly?: boolean;
  highlightLines?: Set<number>;
  highlightType?: "added" | "removed" | "modified";
  label: string;
  lineCount?: boolean;
}

export default function CodeEditor({
  value,
  onChange,
  placeholder,
  readOnly = false,
  label,
}: CodeEditorProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const lineNumbersRef = useRef<HTMLDivElement>(null);
  const [lineCount, setLineCount] = useState(1);

  const updateLineCount = useCallback(() => {
    const lines = value.split("\n").length;
    setLineCount(lines);
  }, [value]);

  useEffect(() => {
    updateLineCount();
  }, [updateLineCount]);

  const syncScroll = () => {
    if (textareaRef.current && lineNumbersRef.current) {
      lineNumbersRef.current.scrollTop = textareaRef.current.scrollTop;
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex items-center justify-between px-4 py-2 bg-gray-800 border-b border-gray-700 rounded-t-xl">
        <span className="text-sm font-medium text-gray-300">{label}</span>
        <span className="text-xs text-gray-500">
          {lineCount} سطر • {value.length} حرف
        </span>
      </div>
      <div className="flex flex-1 overflow-hidden rounded-b-xl bg-gray-900">
        <div
          ref={lineNumbersRef}
          className="select-none overflow-hidden py-3 px-2 text-right bg-gray-900/80 border-r border-gray-700/50 min-w-[3.5rem]"
          style={{ fontFamily: "monospace", fontSize: "13px", lineHeight: "1.6" }}
        >
          {Array.from({ length: lineCount }, (_, i) => (
            <div key={i} className="text-gray-600 pr-2">
              {i + 1}
            </div>
          ))}
        </div>
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onScroll={syncScroll}
          readOnly={readOnly}
          placeholder={placeholder}
          spellCheck={false}
          className="flex-1 bg-transparent text-gray-100 p-3 resize-none outline-none overflow-auto"
          style={{
            fontFamily: "'Fira Code', 'Cascadia Code', 'JetBrains Mono', monospace",
            fontSize: "13px",
            lineHeight: "1.6",
            tabSize: 2,
          }}
          dir="ltr"
        />
      </div>
    </div>
  );
}
