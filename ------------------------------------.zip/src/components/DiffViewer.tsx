import { DiffLine } from "../lib/patcher";

interface DiffViewerProps {
  diff: DiffLine[];
  onClose: () => void;
}

export default function DiffViewer({ diff, onClose }: DiffViewerProps) {
  const addedCount = diff.filter((d) => d.type === "added").length;
  const removedCount = diff.filter((d) => d.type === "removed").length;

  return (
    <div className="flex flex-col h-full bg-gray-900 rounded-xl overflow-hidden border border-gray-700">
      <div className="flex items-center justify-between px-4 py-3 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center gap-4">
          <span className="text-sm font-bold text-white">📊 عرض التغييرات (Diff)</span>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1 text-green-400">
              <span className="w-2 h-2 rounded-full bg-green-400"></span>
              +{addedCount} إضافة
            </span>
            <span className="flex items-center gap-1 text-red-400">
              <span className="w-2 h-2 rounded-full bg-red-400"></span>
              -{removedCount} حذف
            </span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="text-gray-400 hover:text-white transition-colors p-1 rounded hover:bg-gray-700"
        >
          ✕
        </button>
      </div>
      <div
        className="flex-1 overflow-auto p-0"
        style={{
          fontFamily: "'Fira Code', 'Cascadia Code', 'JetBrains Mono', monospace",
          fontSize: "13px",
          lineHeight: "1.6",
        }}
      >
        {diff.map((line, idx) => {
          let bgClass = "";
          let textClass = "text-gray-300";
          let prefix = " ";
          let borderClass = "";

          if (line.type === "added") {
            bgClass = "bg-green-500/10";
            textClass = "text-green-300";
            borderClass = "border-l-2 border-green-500";
            prefix = "+";
          } else if (line.type === "removed") {
            bgClass = "bg-red-500/10";
            textClass = "text-red-300";
            borderClass = "border-l-2 border-red-500";
            prefix = "-";
          } else {
            borderClass = "border-l-2 border-transparent";
          }

          return (
            <div
              key={idx}
              className={`flex ${bgClass} ${borderClass} hover:bg-gray-800/50 transition-colors`}
            >
              <span className="select-none w-12 text-right pr-2 text-gray-600 shrink-0">
                {line.lineNum ?? ""}
              </span>
              <span className="select-none w-12 text-right pr-2 text-gray-600 shrink-0">
                {line.newLineNum ?? ""}
              </span>
              <span className={`select-none w-5 text-center shrink-0 ${line.type === "added" ? "text-green-400" : line.type === "removed" ? "text-red-400" : "text-gray-600"}`}>
                {prefix}
              </span>
              <span className={`flex-1 pr-4 ${textClass} whitespace-pre`} dir="ltr">
                {line.content}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
