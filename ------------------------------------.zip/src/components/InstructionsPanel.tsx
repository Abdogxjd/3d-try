import { useState } from "react";
import { AI_INSTRUCTIONS } from "../lib/patcher";

export default function InstructionsPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [stepsOpen, setStepsOpen] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(AI_INSTRUCTIONS);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
      const ta = document.createElement("textarea");
      ta.value = AI_INSTRUCTIONS;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const steps = [
    {
      num: 1,
      title: "انسخ تعليمات التوجيه",
      desc: "اضغط على زر \"نسخ التعليمات\" أدناه لنسخ تعليمات التوجيه للذكاء الاصطناعي",
      icon: "📋",
    },
    {
      num: 2,
      title: "الصق التعليمات للذكاء الاصطناعي",
      desc: "الصق هذه التعليمات في محادثتك مع نموذج الذكاء الاصطناعي مع طلبك لتعديلات الكود",
      icon: "🤖",
    },
    {
      num: 3,
      title: "انسخ رد النموذج",
      desc: "بعد أن يرد النموذج بالتعديلات بتنسيق JSON، انسخ الرد كاملاً",
      icon: "📑",
    },
    {
      num: 4,
      title: "الصق في منطقة التعديل",
      desc: "الصق رد النموذج في منطقة \"التعديلات\" في الموقع",
      icon: "📝",
    },
    {
      num: 5,
      title: "اضغط تطبيق التعديلات",
      desc: "اضغط على زر \"تطبيق التعديلات\" وسيتم تطبيق جميع التعديلات على الكود تلقائياً",
      icon: "⚡",
    },
    {
      num: 6,
      title: "انسخ الكود النهائي",
      desc: "انسخ الكود الكامل بعد تطبيق جميع التعديلات بدقة",
      icon: "✅",
    },
  ];

  return (
    <div className="space-y-4">
      {/* Steps Button */}
      <button
        onClick={() => setStepsOpen(!stepsOpen)}
        className="w-full flex items-center justify-between px-4 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl transition-all shadow-lg shadow-indigo-500/20"
      >
        <span className="flex items-center gap-2 font-bold">
          <span className="text-lg">📖</span>
          خطوات الاستخدام
        </span>
        <span
          className={`transition-transform duration-300 text-lg ${stepsOpen ? "rotate-180" : ""}`}
        >
          ▼
        </span>
      </button>

      {stepsOpen && (
        <div className="bg-gray-800/90 backdrop-blur-sm rounded-xl border border-gray-700 p-5 space-y-4 animate-in slide-in-from-top-2">
          <h3 className="text-lg font-bold text-white text-center mb-4">
            🚀 كيفية استخدام CodePatcher
          </h3>
          <div className="grid gap-3">
            {steps.map((step) => (
              <div
                key={step.num}
                className="flex items-start gap-3 p-3 bg-gray-700/50 rounded-lg border border-gray-600/30"
              >
                <div className="flex items-center justify-center w-8 h-8 rounded-full bg-indigo-500/20 text-indigo-400 font-bold text-sm shrink-0">
                  {step.num}
                </div>
                <div>
                  <div className="flex items-center gap-2 font-semibold text-white text-sm">
                    <span>{step.icon}</span>
                    {step.title}
                  </div>
                  <p className="text-gray-400 text-xs mt-1">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AI Instructions Section */}
      <div className="bg-gray-800/90 backdrop-blur-sm rounded-xl border border-gray-700 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700">
          <span className="font-bold text-white flex items-center gap-2">
            <span className="text-lg">🧠</span>
            تعليمات التوجيه لنماذج الذكاء الاصطناعي
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                copied
                  ? "bg-green-500/20 text-green-400 border border-green-500/30"
                  : "bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 hover:bg-indigo-500/30"
              }`}
            >
              {copied ? "✓ تم النسخ!" : "📋 نسخ التعليمات"}
            </button>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="px-3 py-1.5 rounded-lg text-sm font-medium bg-gray-700 text-gray-300 hover:bg-gray-600 transition-all"
            >
              <span
                className={`inline-block transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`}
              >
                ▼
              </span>
            </button>
          </div>
        </div>

        {isOpen && (
          <div className="p-4 max-h-96 overflow-auto">
            <pre
              className="text-xs text-gray-300 whitespace-pre-wrap leading-relaxed"
              dir="ltr"
              style={{ fontFamily: "'Fira Code', monospace" }}
            >
              {AI_INSTRUCTIONS}
            </pre>
          </div>
        )}
      </div>
    </div>
  );
}
