// ── Types ──────────────────────────────────────────────
export interface Modification {
  action: "replace" | "insert_after" | "insert_before" | "delete" | "replace_block";
  find?: string;
  start?: string;
  end?: string;
  content?: string;
  description?: string;
}

export interface PatchInstruction {
  modifications: Modification[];
}

export interface PatchResult {
  success: boolean;
  code: string;
  changes: ChangeDetail[];
  errors: string[];
}

export interface ChangeDetail {
  type: "added" | "removed" | "modified";
  lineStart: number;
  lineEnd: number;
  description: string;
}

// ── Helpers ────────────────────────────────────────────

// (escapeRegex reserved for future use)

/**
 * Normalise a search string so we can find it even when the pasted code has
 * slightly different whitespace.  We keep line-structure intact but collapse
 * runs of spaces/tabs on each line and trim each line.
 */
function normaliseLine(line: string): string {
  return line.replace(/\t/g, "  ").replace(/ +/g, " ").trim();
}

/**
 * Find the index range inside `lines` that matches the multi-line search
 * block.  Returns [startIdx, endIdx] (inclusive) or null.
 */
function findBlock(lines: string[], searchLines: string[]): [number, number] | null {
  const normSearch = searchLines.map(normaliseLine).filter((l) => l.length > 0);
  if (normSearch.length === 0) return null;

  for (let i = 0; i <= lines.length - normSearch.length; i++) {
    let matched = true;
    for (let j = 0; j < normSearch.length; j++) {
      if (normaliseLine(lines[i + j]) !== normSearch[j]) {
        matched = false;
        break;
      }
    }
    if (matched) return [i, i + normSearch.length - 1];
  }
  return null;
}

/**
 * Find a single line index by normalised comparison.
 * Returns the 0-based index or -1.
 * If `startFrom` is given, search from that index onward.
 */
function findLine(lines: string[], search: string, startFrom = 0): number {
  const norm = normaliseLine(search);
  for (let i = startFrom; i < lines.length; i++) {
    if (normaliseLine(lines[i]) === norm) return i;
  }
  return -1;
}

/**
 * Detect leading whitespace of an existing line so we can match indentation
 * when inserting new lines.
 */
function detectIndent(line: string): string {
  const m = line.match(/^(\s*)/);
  return m ? m[1] : "";
}

/**
 * Re-indent a block of new content to match the indentation of a reference
 * line.  If the new content already contains its own indentation structure,
 * we preserve relative indentation but shift the base to match.
 */
function reindentBlock(newContent: string, referenceIndent: string): string {
  const newLines = newContent.split("\n");
  // find minimum indent in the new block (ignoring blank lines)
  let minIndent = Infinity;
  for (const l of newLines) {
    if (l.trim().length === 0) continue;
    const m = l.match(/^(\s*)/);
    const len = m ? m[1].length : 0;
    if (len < minIndent) minIndent = len;
  }
  if (minIndent === Infinity) minIndent = 0;

  return newLines
    .map((l) => {
      if (l.trim().length === 0) return "";
      const stripped = l.slice(minIndent);
      return referenceIndent + stripped;
    })
    .join("\n");
}

// ── Main Patcher ───────────────────────────────────────

export function applyPatch(originalCode: string, instruction: PatchInstruction): PatchResult {
  let lines = originalCode.split("\n");
  const changes: ChangeDetail[] = [];
  const errors: string[] = [];

  for (let mi = 0; mi < instruction.modifications.length; mi++) {
    const mod = instruction.modifications[mi];
    const desc = mod.description || `Modification #${mi + 1}`;

    try {
      switch (mod.action) {
        // ── REPLACE (single or multi-line find → replace) ──
        case "replace": {
          if (!mod.find) {
            errors.push(`[${desc}] ❌ الحقل "find" مطلوب لعملية replace`);
            break;
          }
          const searchLines = mod.find.split("\n");
          const result = findBlock(lines, searchLines);
          if (!result) {
            errors.push(`[${desc}] ❌ لم يتم العثور على الكود المطلوب استبداله:\n${mod.find}`);
            break;
          }
          const [start, end] = result;
          const indent = detectIndent(lines[start]);
          const newContent = mod.content ?? "";
          const reindented = reindentBlock(newContent, indent);
          const newLines = reindented.split("\n");
          const removedCount = end - start + 1;
          lines.splice(start, removedCount, ...newLines);
          changes.push({
            type: "modified",
            lineStart: start + 1,
            lineEnd: start + newLines.length,
            description: desc,
          });
          break;
        }

        // ── INSERT_AFTER ──
        case "insert_after": {
          if (!mod.find) {
            errors.push(`[${desc}] ❌ الحقل "find" مطلوب لعملية insert_after`);
            break;
          }
          // Support multi-line find
          const searchLinesAfter = mod.find.split("\n");
          let afterIdx: number;
          if (searchLinesAfter.length > 1) {
            const blockResult = findBlock(lines, searchLinesAfter);
            if (!blockResult) {
              errors.push(`[${desc}] ❌ لم يتم العثور على الكود:\n${mod.find}`);
              break;
            }
            afterIdx = blockResult[1]; // insert after the last line of the block
          } else {
            afterIdx = findLine(lines, mod.find);
            if (afterIdx === -1) {
              errors.push(`[${desc}] ❌ لم يتم العثور على السطر:\n${mod.find}`);
              break;
            }
          }
          const indent = detectIndent(lines[afterIdx]);
          const newContent = mod.content ?? "";
          const reindented = reindentBlock(newContent, indent);
          const newLines = reindented.split("\n");
          lines.splice(afterIdx + 1, 0, ...newLines);
          changes.push({
            type: "added",
            lineStart: afterIdx + 2,
            lineEnd: afterIdx + 1 + newLines.length,
            description: desc,
          });
          break;
        }

        // ── INSERT_BEFORE ──
        case "insert_before": {
          if (!mod.find) {
            errors.push(`[${desc}] ❌ الحقل "find" مطلوب لعملية insert_before`);
            break;
          }
          // Support multi-line find
          const searchLinesBefore = mod.find.split("\n");
          let beforeIdx: number;
          if (searchLinesBefore.length > 1) {
            const blockResult = findBlock(lines, searchLinesBefore);
            if (!blockResult) {
              errors.push(`[${desc}] ❌ لم يتم العثور على الكود:\n${mod.find}`);
              break;
            }
            beforeIdx = blockResult[0]; // insert before the first line of the block
          } else {
            beforeIdx = findLine(lines, mod.find);
            if (beforeIdx === -1) {
              errors.push(`[${desc}] ❌ لم يتم العثور على السطر:\n${mod.find}`);
              break;
            }
          }
          const indent = detectIndent(lines[beforeIdx]);
          const newContent = mod.content ?? "";
          const reindented = reindentBlock(newContent, indent);
          const newLines = reindented.split("\n");
          lines.splice(beforeIdx, 0, ...newLines);
          changes.push({
            type: "added",
            lineStart: beforeIdx + 1,
            lineEnd: beforeIdx + newLines.length,
            description: desc,
          });
          break;
        }

        // ── DELETE ──
        case "delete": {
          if (!mod.find) {
            errors.push(`[${desc}] ❌ الحقل "find" مطلوب لعملية delete`);
            break;
          }
          const searchLines = mod.find.split("\n");
          const result = findBlock(lines, searchLines);
          if (!result) {
            errors.push(`[${desc}] ❌ لم يتم العثور على الكود المطلوب حذفه:\n${mod.find}`);
            break;
          }
          const [start, end] = result;
          lines.splice(start, end - start + 1);
          changes.push({
            type: "removed",
            lineStart: start + 1,
            lineEnd: end + 1,
            description: desc,
          });
          break;
        }

        // ── REPLACE_BLOCK (find by start/end markers) ──
        case "replace_block": {
          if (!mod.start || !mod.end) {
            errors.push(`[${desc}] ❌ الحقول "start" و "end" مطلوبة لعملية replace_block`);
            break;
          }
          const startIdx = findLine(lines, mod.start);
          if (startIdx === -1) {
            errors.push(`[${desc}] ❌ لم يتم العثور على بداية البلوك:\n${mod.start}`);
            break;
          }
          const endIdx = findLine(lines, mod.end, startIdx);
          if (endIdx === -1) {
            errors.push(`[${desc}] ❌ لم يتم العثور على نهاية البلوك:\n${mod.end}`);
            break;
          }
          const indent = detectIndent(lines[startIdx]);
          const newContent = mod.content ?? "";
          const reindented = reindentBlock(newContent, indent);
          const newLines = reindented.split("\n");
          lines.splice(startIdx, endIdx - startIdx + 1, ...newLines);
          changes.push({
            type: "modified",
            lineStart: startIdx + 1,
            lineEnd: startIdx + newLines.length,
            description: desc,
          });
          break;
        }

        default:
          errors.push(`[${desc}] ❌ نوع العملية غير معروف: ${(mod as any).action}`);
      }
    } catch (err: any) {
      errors.push(`[${desc}] ❌ خطأ غير متوقع: ${err.message}`);
    }
  }

  return {
    success: errors.length === 0,
    code: lines.join("\n"),
    changes,
    errors,
  };
}

// ── Parse AI response ──────────────────────────────────

export function parseAIResponse(text: string): PatchInstruction | null {
  // Try to extract JSON from the text
  // First try: look for ```json ... ``` block
  const jsonBlockMatch = text.match(/```(?:json)?\s*\n?([\s\S]*?)\n?\s*```/);
  let jsonStr = jsonBlockMatch ? jsonBlockMatch[1] : text;

  // Try to find a JSON object in the text
  const jsonObjMatch = jsonStr.match(/\{[\s\S]*\}/);
  if (jsonObjMatch) {
    jsonStr = jsonObjMatch[0];
  }

  try {
    const parsed = JSON.parse(jsonStr);
    if (parsed.modifications && Array.isArray(parsed.modifications)) {
      return parsed as PatchInstruction;
    }
    // Maybe it's just an array
    if (Array.isArray(parsed)) {
      return { modifications: parsed };
    }
    return null;
  } catch {
    return null;
  }
}

// ── Compute simple diff ────────────────────────────────

export interface DiffLine {
  type: "same" | "added" | "removed";
  lineNum: number | null;
  newLineNum: number | null;
  content: string;
}

export function computeDiff(original: string, modified: string): DiffLine[] {
  const origLines = original.split("\n");
  const modLines = modified.split("\n");

  // Simple LCS-based diff
  const m = origLines.length;
  const n = modLines.length;

  // For very large files, use a simpler approach
  if (m * n > 10_000_000) {
    return simpleDiff(origLines, modLines);
  }

  // LCS table
  const dp: number[][] = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (origLines[i - 1] === modLines[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1] + 1;
      } else {
        dp[i][j] = Math.max(dp[i - 1][j], dp[i][j - 1]);
      }
    }
  }

  // Backtrack
  let i = m,
    j = n;
  const temp: DiffLine[] = [];

  while (i > 0 || j > 0) {
    if (i > 0 && j > 0 && origLines[i - 1] === modLines[j - 1]) {
      temp.push({ type: "same", lineNum: i, newLineNum: j, content: origLines[i - 1] });
      i--;
      j--;
    } else if (j > 0 && (i === 0 || dp[i][j - 1] >= dp[i - 1][j])) {
      temp.push({ type: "added", lineNum: null, newLineNum: j, content: modLines[j - 1] });
      j--;
    } else {
      temp.push({ type: "removed", lineNum: i, newLineNum: null, content: origLines[i - 1] });
      i--;
    }
  }

  return temp.reverse();
}

function simpleDiff(origLines: string[], modLines: string[]): DiffLine[] {
  const result: DiffLine[] = [];
  let oi = 0, mi = 0;
  
  while (oi < origLines.length || mi < modLines.length) {
    if (oi < origLines.length && mi < modLines.length && origLines[oi] === modLines[mi]) {
      result.push({ type: "same", lineNum: oi + 1, newLineNum: mi + 1, content: origLines[oi] });
      oi++;
      mi++;
    } else if (oi < origLines.length && mi < modLines.length) {
      result.push({ type: "removed", lineNum: oi + 1, newLineNum: null, content: origLines[oi] });
      result.push({ type: "added", lineNum: null, newLineNum: mi + 1, content: modLines[mi] });
      oi++;
      mi++;
    } else if (oi < origLines.length) {
      result.push({ type: "removed", lineNum: oi + 1, newLineNum: null, content: origLines[oi] });
      oi++;
    } else {
      result.push({ type: "added", lineNum: null, newLineNum: mi + 1, content: modLines[mi] });
      mi++;
    }
  }
  
  return result;
}

// ── AI Instructions ────────────────────────────────────

export const AI_INSTRUCTIONS = `# تعليمات تنسيق تعديلات الكود - CodePatcher

عند طلب تعديلات على كود، يجب أن تكتب التعديلات بتنسيق JSON محدد. لا تكتب الكود الكامل بعد التعديل، فقط اكتب التعديلات المطلوبة.

## التنسيق المطلوب:

\`\`\`json
{
  "modifications": [
    {
      "action": "نوع_العملية",
      "find": "الكود_المراد_البحث_عنه",
      "content": "الكود_الجديد",
      "description": "وصف_التعديل"
    }
  ]
}
\`\`\`

## أنواع العمليات المتاحة:

### 1. replace - استبدال كود بكود آخر
استخدمه عندما تريد تغيير سطر أو عدة أسطر موجودة.
\`\`\`json
{
  "action": "replace",
  "find": "const x = 5;\\nconst y = 10;",
  "content": "const x = 50;\\nconst y = 100;\\nconst z = 200;",
  "description": "تحديث قيم المتغيرات"
}
\`\`\`

### 2. insert_after - إضافة كود بعد سطر معين
\`\`\`json
{
  "action": "insert_after",
  "find": "const x = 5;",
  "content": "const y = 10;\\nconst z = 15;",
  "description": "إضافة متغيرات جديدة"
}
\`\`\`

### 3. insert_before - إضافة كود قبل سطر معين
\`\`\`json
{
  "action": "insert_before",
  "find": "return result;",
  "content": "console.log(result);",
  "description": "إضافة سجل قبل الإرجاع"
}
\`\`\`

### 4. delete - حذف كود
\`\`\`json
{
  "action": "delete",
  "find": "console.log('debug');\\nconsole.log('test');",
  "description": "حذف سجلات التصحيح"
}
\`\`\`

### 5. replace_block - استبدال بلوك كامل (من سطر بداية إلى سطر نهاية)
مفيد لاستبدال دوال كاملة أو بلوكات كبيرة بدون الحاجة لنسخ كل سطر في find.
\`\`\`json
{
  "action": "replace_block",
  "start": "function calculateTotal() {",
  "end": "}",
  "content": "function calculateTotal() {\\n  const subtotal = items.reduce((sum, item) => sum + item.price, 0);\\n  const tax = subtotal * 0.15;\\n  return subtotal + tax;\\n}",
  "description": "إعادة كتابة دالة الحساب"
}
\`\`\`

## قواعد مهمة:

1. **في حقل find**: اكتب الكود كما هو موجود بالضبط في الملف الأصلي. استخدم \\n للأسطر الجديدة.
2. **في حقل content**: اكتب الكود الجديد الذي سيحل محل الكود القديم. استخدم \\n للأسطر الجديدة.
3. **المسافات البادئة (indentation)**: لا تقلق بشأنها، النظام سيحافظ عليها تلقائياً.
4. **الترتيب مهم**: رتب التعديلات من أعلى الملف إلى أسفله.
5. **كن دقيقاً**: في حقل find اكتب كوداً كافياً ليكون فريداً في الملف (لا يتكرر).
6. **وصف كل تعديل**: اكتب وصفاً مختصراً في description لكل تعديل.
7. **لا تكتب الكود الكامل**: فقط التعديلات. هذا يوفر الوقت والتوكينات.

## مثال كامل:

إذا كان الكود الأصلي:
\`\`\`javascript
function greet(name) {
  console.log("Hello " + name);
}

function add(a, b) {
  return a + b;
}
\`\`\`

وتريد: تعديل دالة greet، إضافة دالة جديدة بعد add، وحذف console.log:

\`\`\`json
{
  "modifications": [
    {
      "action": "replace",
      "find": "console.log(\\"Hello \\" + name);",
      "content": "const message = \\"Hello \\" + name + \\"!\\";\\nreturn message;",
      "description": "تعديل دالة greet لتعيد القيمة بدل طباعتها"
    },
    {
      "action": "insert_after",
      "find": "function add(a, b) {",
      "content": "  // جمع رقمين وإرجاع النتيجة",
      "description": "إضافة تعليق توضيحي للدالة"
    },
    {
      "action": "insert_after",
      "find": "  return a + b;\\n}",
      "content": "\\nfunction multiply(a, b) {\\n  return a * b;\\n}",
      "description": "إضافة دالة الضرب"
    }
  ]
}
\`\`\`

استخدم هذا التنسيق دائماً عند طلب تعديلات على الكود.`;
